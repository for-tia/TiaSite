import os
import discord
from discord.ext import commands
from os import environ
from dotenv import load_dotenv

load_dotenv()
token = environ["TOKEN"]
client = commands.Bot(command_prefix="t!", activity=discord.Game(name="t!begin"), help_command=None)

for file in os.listdir("cogs"):
    if file.endswith(".py"):
        client.load_extension(f"cogs.{file[:-3]}")
        print(f"loaded {file[:-3]}!")
    else:
        print(f"didn't load {file[:-3]} :(")


@client.event
async def on_ready():
    print(f"Logged in as {client.user.name}")


client.run(token)
