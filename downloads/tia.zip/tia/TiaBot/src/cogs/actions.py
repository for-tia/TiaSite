import discord
from discord.ext import commands
from random import choice


class Action(commands.Cog):
    def __init__(self, client):
        self.client = client

        @client.command()
        async def hug(ctx, huge: discord.Member = None):
            names = ["how cute", "how sweet", "how nice", "aww", "hehe", "cute"]
            links = ["https://i.imgur.com/643i9xN.gif", "https://i.imgur.com/u3NRTmW.gif",
                     "https://i.imgur.com/cCHVbbc.gif", "https://i.imgur.com/FKZb30O.gif",
                     "https://i.imgur.com/cCHVbbc.gif", "https://i.imgur.com/P73sKld.gif",
                     "https://i.imgur.com/u52xmsE.gif", "https://i.imgur.com/5xCqf4y.gif",
                     "https://i.imgur.com/XpeKpLn.gif", "https://i.imgur.com/5xCqf4y.gif"]

            if huge is None:
                await ctx.send(
                    f"You cant hug air, {ctx.author.mention}!\nI'll hug you if you want!"
                )
            elif huge == ctx.author:
                selfembed = discord.Embed(title=f"Tia hugs {ctx.author}, {choice(names)}!",
                                          color=discord.Color.random())
                selfembed.set_image(url=choice(links))
                await ctx.send(
                    f"Nuuu! I will hug you!",
                    embed=selfembed
                )
            else:
                huggieembed = discord.Embed(title=f"{ctx.author} hugs {huge}, {choice(names)}!",
                                            color=discord.Color.random())
                huggieembed.set_image(url=choice(links))
                await ctx.send(
                    embed=huggieembed
                )

        @client.command(alieses=["pats"])
        async def pat(ctx, patee: discord.Member = None):
            names = ["how cute", "how sweet", "how nice", "aww", "hehe", "cute"]
            links = ["https://i.imgur.com/OZZlla1.gif", "https://i.imgur.com/Bzi6X5a.gif",
                     "https://i.imgur.com/hHvsnXm.gif", "https://i.imgur.com/CrMRrDV.gif",
                     "https://i.imgur.com/AQiHFGv.gif", "https://i.imgur.com/ioha7Rf.gif",
                     "https://i.imgur.com/3ab5ec9.gif", "https://i.imgur.com/3ab5ec9.gif",
                     "https://i.imgur.com/qol3AO5.gif", "https://i.imgur.com/o6e5k3a.gif"]

            if patee is None:
                await ctx.send(
                    f"You cant pat air, {ctx.author.mention}!\nI'll hug you if you want!"
                )
            elif patee == ctx.author:
                selfembed = discord.Embed(title=f"Tia pats {ctx.author}, {choice(names)}!",
                                          color=discord.Color.random())
                selfembed.set_image(url=choice(links))
                await ctx.send(
                    f"Nuuu! I will hug you!",
                    embed=selfembed
                )
            else:
                pattieembed = discord.Embed(title=f"{ctx.author} pats {patee}, {choice(names)}!",
                                            color=discord.Color.random())
                pattieembed.set_image(url=choice(links))
                await ctx.send(
                    embed=pattieembed
                )


def setup(client):
    client.add_cog(Action(client))
