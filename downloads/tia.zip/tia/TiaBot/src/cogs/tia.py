import discord
from discord.ext import commands


class Main(commands.Cog):
    def __init__(self, client):
        self.client = client

        @client.command()
        async def ping(ctx):
            await ctx.send(f"Pong, {ctx.author.mention}!")

        @client.command()
        async def begin(ctx):
            tiausr = await client.fetch_user(576710397147742209)
            tiaembed = discord.Embed(title="Hi!",
                                     description="I'm TiaBot! For more general information, please type t!tia!\n"
                                                 "This command shows information about the commands!",
                                     color=discord.Color.random())
            tiaembed.add_field(name="Commands",
                               value="t!hug (user) - Hugs an user!\n"
                                     "t!pat (user) - Pats an user!\n"
                                     "t!begin - Shows information about my commands!\n"
                                     "t!tia - Shows General information about me!\n"
                                     "t!init create - Creates a little role!\n"
                                     "t!init add - Adds the little role to me!\n"
                                     "ehzduh ri wkh phvvb fdsv\n"
                                     "t!crack (user) - Crack an user, aww how cute!\n"
                                     "t!cracked check - Shows who is currently cracked!\n"
                                     "t!cracked stop - Times up! Stops an user from being cracked!\n",
                               inline=False)
            tiaembed.set_author(name=f"{tiausr.name}", icon_url=f"{tiausr.avatar_url}")

            await ctx.send(
                embed=tiaembed
            )

        @client.command(pass_context=True)
        @commands.has_permissions(manage_roles=True)
        async def init(ctx, *, arg=""):
            if arg == "create":
                await ctx.guild.create_role(name="lil Tia", colour=discord.Colour(0x9656b2))
                await ctx.guild.create_role(name="Cracked!", colour=discord.Colour(0xeb9de8))
                await ctx.send("Role 'lil Tia' and 'Cracked!' have been created!\nAdd the role to me by typing "
                               "'t!init add'")
            elif arg == "add":
                guild = ctx.guild
                tiabotusr = guild.get_member(1006223986725757038)
                lilrole = discord.utils.get(guild.roles, name="lil Tia")

                await tiabotusr.add_roles(lilrole)
                await ctx.send("Done!")

        @client.command()
        async def tia(ctx):
            await ctx.send('```c\n#include <stdio.h>\n#include <stdlib.h>\n\nint main(void) {\n'
                           '    puts("Hello! My naMe is Tia!");\n'
                           '    puts("not to be cOnfused with the amazing real Tia!");\n'
                           '    puts("I have been made as a thank you for being such a great friend and person");\n'
                           '    puts("I destroy all dread with my wholesome commanDs!");\n\nreturn 0;\n}```')


def setup(client):
    client.add_cog(Main(client))
