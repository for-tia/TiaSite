from discord.ext import commands


class Secrets(commands.Cog):
    def __init__(self, client):
        self.client = client

        @client.command()
        async def mod(ctx):
            await ctx.send(
                "This is a test command."
            )


def setup(client):
    client.add_cog(Secrets(client))
