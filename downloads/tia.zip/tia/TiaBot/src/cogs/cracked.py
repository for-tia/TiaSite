import discord
from discord.ext import commands

iscracked = False
cracked_user = None


class Cracked(commands.Cog):
    def __init__(self, client):
        self.client = client

        @client.command()
        async def crack(ctx, m: discord.Member = None):
            global cracked_user, iscracked

            if m is None:
                await ctx.send(
                    f"You can't just crack no one, {ctx.author.mention}!"
                )
            elif m == ctx.author:
                await ctx.send(
                    f"You can't just crack yourself, {ctx.author.mention}!"
                )
            else:
                iscracked = True
                cracked_user = m
                guild = ctx.guild
                crackedrole = discord.utils.get(guild.roles, name="Cracked!")

                await cracked_user.add_roles(crackedrole)
                await ctx.send(
                    f"Aww {m.mention} is broken! How cute!"
                )

        @client.command()
        async def cracked(ctx, *, arg=""):
            global cracked_user, iscracked

            if arg == "check":
                if iscracked is False:
                    await ctx.send(
                        "No one is cracked right now!"
                    )
                elif iscracked is True:
                    await ctx.send(
                        f"{cracked_user} is cracked!"
                    )
            elif arg == "stop":
                guild = ctx.guild
                crackedrole = discord.utils.get(guild.roles, name="Cracked!")

                await cracked_user.remove_roles(crackedrole)
                await ctx.send(
                    f"Stopped cracking! {cracked_user.mention} is now sleeping!"
                )

                iscracked = False
                cracked_user = None
            elif arg == "":
                await ctx.send(
                    "Please enter a valid argument!"
                )


def setup(client):
    client.add_cog(Cracked(client))
